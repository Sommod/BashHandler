#include "../header_files/internal_commands.h" // String, Vector
#include "../header_files/util.h" // String, Vector, Unistd.h


std::string internal_shift(std::string args){
    return "";
}


