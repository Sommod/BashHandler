# Project 4

List of Commands:
- make (This will compile the entire project. Will only compiled missing files)
- make run (Runs the program with NO arguments)
- make clean (Removes ALL compiled files AND 'object_files' folder)